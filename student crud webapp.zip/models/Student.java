package models;

import java.util.HashSet;
import java.util.Set;

public class Student {

    public static Integer id;
    public  static String fname;
    public static String lname;
    public static String course;


    public Student(){

    }

    public Student(Integer id, String fname, String lname, String course){
        this.id=id;
        this.fname=fname;
        this.lname=lname;
        this.course=course;
    }

    private static Set<Student> students;


    static {
        students=new HashSet<>();
        students.add(new Student(id= 1, fname= "Ritika", lname= "Khatri", course= "BCA"));
        students.add(new Student(id= 2, fname= "Naman", lname= "Khatri", course= "B.Tech"));
    }

    public static Set<Student> allStudents(){
        return students;
    }

    public static Student findById(Integer id){
        for (Student student : students){
            if(id.equals(student.id)){
                return student;
            }
        }
        return null;
    }

    public static void add(Student student){
        students.add(student);
    }

    public static boolean remove(Student student){
        return students.remove(student);
    }
}
