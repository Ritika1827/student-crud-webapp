package controllers;

import models.Student;
import play.data.Form;
import play.data.FormFactory;
import play.mvc.Controller;
import play.mvc.Result;

import java.util.Set;

import views.html.students.show;
import views.html.students.edit;
import views.html.students.index;
import views.html.students.create;

import javax.inject.Inject;


public class studentController extends Controller {
    @inject
    FormFactory formFactory;
// For all students
    public Result index(){

        Set<Student> students = Student.allStudents();

        Result ok = ok(index.render(students));
        return ok;
    }
// To create students
    public Result create(){
       Form<Student> studentForm = formFactory.form(Student.class);
        return ok(create.render(studentForm));
    }
// To save students
    public Result save(){
        Form<Student> studentForm = formFactory.form(Student.class).bindFromRequest();
        Student student = studentForm.get();
        Student.add(student);
        return redirect(routes.studentController.index());
    }
    public Result edit(Integer id){
        Student student = Student.findById(id);
        if(student==null)
            return notFound("Student not found");

        Form<Student> studentForm = formFactory.form(Student.class).fill(student);
        return ok(edit.render(studentForm));
    }
    public Result update(){
        Form<Student> studentForm = formFactory.form(Student.class).bindFromRequest();
        Student student = studentForm.get();
        Student oldStudent = Student.findById(student.id);
        if(oldStudent==null)
            return notFound("Student not found");
        oldStudent.fname=student.fname;
        oldStudent.lname=student.lname;
        oldStudent.course=student.course;
        return redirect(routes.studentController.index()) ;
    }
    public Result delete(Integer id){
        Student student = Student.findById(id);
        if(student==null)
            return notFound("student not found");
        Student.remove(student);
        return redirect(routes.studentController.index());
    }
// for student details
    public Result show(Integer id){
        Student student = Student.findById(id);
        if (student==null)
            return notFound("Student not found");
        return ok(show.render(student));
    }
}
